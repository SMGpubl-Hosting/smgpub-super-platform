const express = require('express');
const jwt = require('jsonwebtoken');
const Stripe = require('stripe');
const app = express();
app.use(express.json());

app.post('/auth/register', (req,res)=>res.json({ok:true}));
app.post('/auth/login',(req,res)=>{
  const token = jwt.sign({id:1,role:'admin'}, process.env.JWT_SECRET);
  res.json({token});
});

app.post('/webhooks/stripe', (req,res)=>{
  res.json({received:true});
});

app.listen(3000,()=>console.log('Enterprise API running'));
