# SMGPUB LAUNCH MODE
Live-ready connected scaffolding for deployment