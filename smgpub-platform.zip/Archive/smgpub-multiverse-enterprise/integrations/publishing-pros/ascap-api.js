// Placeholder for ascap-api.js
