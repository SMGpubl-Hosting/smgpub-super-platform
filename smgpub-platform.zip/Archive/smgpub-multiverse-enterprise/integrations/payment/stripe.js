// Placeholder for stripe.js
