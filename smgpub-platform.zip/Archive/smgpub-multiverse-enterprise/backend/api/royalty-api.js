javascript export default function handler(req,res){ res.status(200).json({ royalties: [ {track:'Track1', amount:10}, {track:'Track2', amount:15} ]}); }

