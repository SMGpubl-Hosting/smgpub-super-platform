javascript export default function handler(req,res){ res.status(200).json({ message:'Upload endpoint (mock)' }); }

