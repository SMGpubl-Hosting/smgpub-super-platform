export default function handler(req, res) {
  if(req.method === 'POST') {
    const { email, password } = req.body;
    // Placeholder authentication logic
    res.status(200).json({ message: `User ${email} signed up successfully.` });
  } else {
    res.status(405).json({ error: 'Method not allowed' });
  }
}
