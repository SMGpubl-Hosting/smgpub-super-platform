// Placeholder for distribution-worker.js
