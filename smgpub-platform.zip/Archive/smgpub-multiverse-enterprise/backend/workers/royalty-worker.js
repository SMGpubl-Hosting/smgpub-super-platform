// Placeholder for royalty-worker.js
