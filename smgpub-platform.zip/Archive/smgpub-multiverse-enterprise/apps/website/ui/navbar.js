```javascript import Link from ‘next/link’; export default function Navbar() { return (<nav style={{padding:‘10px’, background:’#222’, color:’#fff’}}>Home
js
