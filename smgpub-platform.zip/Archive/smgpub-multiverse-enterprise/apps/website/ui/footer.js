
javascript export default function Footer() { return (<footer style={{padding:'10px', background:'#222', color:'#fff', textAlign:'center'}}>&copy; 2026 SMGPUB. All rights reserved.</footer>); }

