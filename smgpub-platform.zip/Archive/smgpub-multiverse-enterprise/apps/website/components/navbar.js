export default function Navbar() {
  return (
    <nav style={{background:'#222', color:'#fff', padding:'10px'}}>
      <a href="#home" style={{color:'#fff', marginRight:'10px'}}>Home</a>
      <a href="#pricing" style={{color:'#fff', marginRight:'10px'}}>Pricing</a>
      <a href="#marketplace" style={{color:'#fff', marginRight:'10px'}}>Marketplace</a>
    </nav>
  );
}