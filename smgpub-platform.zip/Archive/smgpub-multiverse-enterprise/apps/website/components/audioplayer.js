javascript export default function AudioPlayer({ src }) { return (<audio controls src={src} style={{margin:'10px 0'}}></audio>); }
