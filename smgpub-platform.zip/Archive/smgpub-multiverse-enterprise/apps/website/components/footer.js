export default function Footer() {
  return <footer style={{background:'#222', color:'#fff', textAlign:'center', padding:'10px'}}>© 2026 SMGPUB. All rights reserved.</footer>;
}

