// Placeholder for register-work.js
