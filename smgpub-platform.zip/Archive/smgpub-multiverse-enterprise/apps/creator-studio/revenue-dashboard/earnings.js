// Placeholder for earnings.js
