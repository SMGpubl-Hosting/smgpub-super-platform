// Placeholder for smgpub-android.js
