// Placeholder for smgpub-ios.js
