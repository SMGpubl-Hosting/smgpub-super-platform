export function toast(msg) {
  const div = document.createElement("div");
  div.className = "toast";
  div.textContent = msg;
  document.body.appendChild(div);

  setTimeout(() => div.remove(), 3000);
}
