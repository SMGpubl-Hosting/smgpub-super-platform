export function kitCard(kit) {
  const div = document.createElement("div");
  div.className = "kit-card";
  div.textContent = kit.name;
  return div;
}
