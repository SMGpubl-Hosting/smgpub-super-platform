const KIT_OPTIONS = ["Night Drive", "City Lights", "Midnight Flow"];

function $(selector) {
  return document.querySelector(selector);
}

function setStatus(message, type = "default") {
  const statusEl = $("#status");
  statusEl.textContent = message;
  statusEl.classList.remove("status-loading", "status-error");

  if (type === "loading") {
    statusEl.classList.add("status-loading");
  } else if (type === "error") {
    statusEl.classList.add("status-error");
  }
}

function createResultItem(item, baseUrlKey) {
  const li = document.createElement("li");

  const labelDiv = document.createElement("div");
  labelDiv.className = "result-label";
  labelDiv.textContent = item.path || item.url || "";

  const typeDiv = document.createElement("div");
  typeDiv.className = "result-type";
  typeDiv.textContent = item.type || "";

  const left = document.createElement("div");
  left.appendChild(labelDiv);
  left.appendChild(typeDiv);

  const right = document.createElement("div");
  right.className = "result-actions";

  if (item.exists) {
    const link = document.createElement("a");
    link.href = item.path || item.url;
    link.textContent = "Download";
    link.setAttribute("download", "");
    right.appendChild(link);
  } else {
    const missing = document.createElement("span");
    missing.className = "result-missing";
    missing.textContent = "File not found";
    right.appendChild(missing);
  }

  li.appendChild(left);
  li.appendChild(right);
  return li;
}

async function generateKit() {
  const kitSelect = $("#kit-select");
  const selectedKit = kitSelect.value;

  setStatus(`Generating kit "${selectedKit}"...`, "loading");

  try {
    const response = await fetch("/api/generate-kit", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ kitName: selectedKit }),
    });

    if (!response.ok) {
      throw new Error(`Server responded with status ${response.status}`);
    }

    const data = await response.json();

    if (!data.success) {
      throw new Error(data.message || "Generation failed");
    }

    const stemsList = $("#stems-list");
    const metadataList = $("#metadata-list");
    stemsList.innerHTML = "";
    metadataList.innerHTML = "";

    (data.stems || []).forEach((stem) => {
      stemsList.appendChild(createResultItem(stem));
    });

    (data.metadata || []).forEach((meta) => {
      metadataList.appendChild(createResultItem(meta));
    });

    setStatus(`Done. Generated kit "${data.kitName}".`);
  } catch (err) {
    console.error(err);
    setStatus(`Error: ${err.message}`, "error");
  }
}

function init() {
  const kitSelect = $("#kit-select");
  KIT_OPTIONS.forEach((kit) => {
    const option = document.createElement("option");
    option.value = kit;
    option.textContent = kit;
    kitSelect.appendChild(option);
  });

  $("#generate-btn").addEventListener("click", generateKit);

  setStatus("Ready.");
}

document.addEventListener("DOMContentLoaded", init);
