import os
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
AUDIO_DIR = os.path.join(BASE_DIR, "storage", "audio")
ARTWORK_DIR = os.path.join(BASE_DIR, "storage", "artwork")

STEM_TYPES = ["808s", "drums", "melodies", "basslines", "fx"]


def normalize_kit_name(kit_name: str) -> str:
  return kit_name.replace(" ", "_")


def build_file_info(kit_name: str):
  normalized = normalize_kit_name(kit_name)

  stems = []
  metadata = []

  for stem_type in STEM_TYPES:
    audio_filename = f"{normalized}_{stem_type}.wav"
    audio_rel_path = os.path.join("storage", "audio", audio_filename)
    audio_abs_path = os.path.join(AUDIO_DIR, audio_filename)
    audio_exists = os.path.isfile(audio_abs_path)

    stems.append(
      {
        "type": stem_type,
        "path": audio_rel_path.replace("\\", "/"),
        "exists": bool(audio_exists),
      }
    )

    meta_filename = f"{normalized}_{stem_type}_metadata.json"
    meta_rel_path = os.path.join("storage", "artwork", meta_filename)
    meta_abs_path = os.path.join(ARTWORK_DIR, meta_filename)
    meta_exists = os.path.isfile(meta_abs_path)

    metadata.append(
      {
        "type": stem_type,
        "path": meta_rel_path.replace("\\", "/"),
        "exists": bool(meta_exists),
      }
    )

  return stems, metadata


@app.route("/api/generate-kit", methods=["POST"])
def generate_kit():
  try:
    payload = request.get_json(force=True, silent=True) or {}
    kit_name = payload.get("kitName")

    if not kit_name or not isinstance(kit_name, str):
      return jsonify({"success": False, "message": "kitName is required"}), 400

    stems, metadata = build_file_info(kit_name)

    response = {
      "success": True,
      "kitName": kit_name,
      "stems": stems,
      "metadata": metadata,
    }
    return jsonify(response)
  except Exception as e:
    return jsonify({"success": False, "message": str(e)}), 500


if __name__ == "__main__":
  # Ensure storage directories exist
  os.makedirs(AUDIO_DIR, exist_ok=True)
  os.makedirs(ARTWORK_DIR, exist_ok=True)
  contracts_dir = os.path.join(BASE_DIR, "storage", "contracts")
  os.makedirs(contracts_dir, exist_ok=True)

  app.run(host="0.0.0.0", port=5000, debug=True)
