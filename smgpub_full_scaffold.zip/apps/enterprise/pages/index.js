export default function Home() {
  return <h1>enterprise running</h1>;
}
