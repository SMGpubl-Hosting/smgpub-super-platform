export default function Home() {
  return <h1>web running</h1>;
}
