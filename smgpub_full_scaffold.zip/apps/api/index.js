const express = require('express');
const jwt = require('jsonwebtoken');
const Stripe = require('stripe');
const AWS = require('aws-sdk');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
const s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION
});

// Auth
app.post('/auth/login', (req, res) => {
  const token = jwt.sign({ userId: 1 }, process.env.JWT_SECRET);
  res.json({ token });
});

// Stripe
app.post('/payments/create-intent', async (req, res) => {
  const intent = await stripe.paymentIntents.create({
    amount: 1000,
    currency: 'usd'
  });
  res.json(intent);
});

// S3 upload URL
app.get('/upload-url', async (req, res) => {
  const url = s3.getSignedUrl('putObject', {
    Bucket: process.env.STORAGE_AUDIO_BUCKET,
    Key: `uploads/${Date.now()}.mp3`,
    Expires: 60
  });
  res.json({ url });
});

app.listen(3000, () => console.log('API running'));
